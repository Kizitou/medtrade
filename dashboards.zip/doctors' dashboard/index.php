<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">

        <link rel="icon" href="assets/images/.jpg">
        <title>My Dashboard || Firstmedtrade Africa - Africa's foremost online medical platform.</title>

        <link href="../users%20dashboard/assets/css/main.css" type="text/css" rel="stylesheet"/>
        <link rel="stylesheet" type="text/css" href="../users%20dashboard/assets/css/mediaqueries.css" />
        <link rel="stylesheet" href="https://cdn.materialdesignicons.com/3.2.89/css/materialdesignicons.min.css">
    </head>
    <body>
        <div class="profilewrapper profile doc">
            <div class="profile-left sidebarnav-width">
                <div class="profile-sidenav">
                    <span id="exitpa"><i class="mdi mdi-close"></i></span>
                    <p><a href="#" class="active"><i class="mdi mdi-speedometer"></i>DASHBOARD</a></p>
                    <hr>
                    <p><a href="./appointments.php"><i class="mdi mdi-briefcase"></i>MY APPOINTMENTS</a></p>
                    <p><a href="./schedule.php"><i class="mdi mdi-calendar-multiselect"></i>MY SCHEDULER</a></p>
                    <hr>
                    <p><a href="./profile.php"><i class="mdi mdi-account"></i>PROFILE DATA</a></p>
                    <p><a href="./password.php"><i class="mdi mdi-lock-open-outline"></i>CHANGE PASSWORD</a></p>
                </div>
                <div class="sidenav-footer">
                    <div class="sidenav-footer-links">
                        <a href="#"><i class="mdi mdi-logout"></i>Logout</a>
                    </div>
                </div>
            </div>
            <div class="profile-right marginal">
                <div class="profile-nav">
                    <span id="sidenav-opener"><i class="mdi mdi-menu"></i></span>
                    <div class="profilenav-left">
                        <div id="profilenav-left-image">
                            <img src="assets/images/FMedTrademinilogo.png">
                        </div>
                        <div id="profilenav-left-text">
                            <h5>Firstmedtrade</h5>
                        </div>
                    </div>
                    <div class="profilenav-right">
                        <div class="welcome-user">
                            <div class="user-div">
                                <div class="user-img">
                                    <i class="mdi mdi-account-outline"></i>
                                </div>
                                <?php echo '<p>Ubyjude Josh</p>'?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="profilebody">
                    <div class="profilepage-pagination">
                        <div class="pageNumber">
                            <?php echo '<h5>Welcome, Dr. Ubyjude</h5>'; ?>
                            <p><a href="#"><i class="mdi mdi-home"></i>Home</a> / Dashboard</p>
                        </div>
                    </div>
                    <div class="profilebody-body">
                        <div class="profilebody-left">
                            <div class="row">
                                <div class="profile-card">
                                    <div class="profile-card-body">
                                        <div class="profile-card-title-options">
                                            <div id="profile-card-title-options-body">
                                                <div id="dp">
                                                    <div id="dp-img"></div>
                                                </div>
                                                <ul id="profile-details">
                                                    <li><p>Ubyjude Joshua</p></li>
                                                    <li><p>Officialuby@gmail.com</p></li>
                                                    <li><p>08119334926</p></li>
                                                </ul>
                                                <a href="./profile.php">Edit</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="profilebody-right">
                            <div class="row">
                                <div class="profile-card no-display">
                                    <div class="profile-card-body">
                                    </div>
                                </div>
                                <div class="profile-card">
                                    <div class="profile-card-body">
                                        <div class="profile-card-title-options">
                                            <div id="profile-card-title-options-body">
                                                <i class="mdi mdi-briefcase"></i>
                                                <div class="profile-card-title">
                                                    <div class="profile-card-title-text">
                                                        <h1>Appointments</h1>
                                                    </div>
                                                </div>
                                                <div id="link-hold"><a href="./appointments.php">View</a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="profile-card">
                                    <div class="profile-card-body">
                                        <div class="profile-card-title-options">
                                            <div id="profile-card-title-options-body">
                                                <i class="mdi mdi-calendar-multiselect"></i>
                                                <div class="profile-card-title">
                                                    <div class="profile-card-title-text">
                                                        <h1>Schedule</h1>
                                                    </div>
                                                </div>
                                                <div id="link-hold"><a href="./schedule.php">View</a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="profile-card">
                                    <div class="profile-card-body">
                                        <div class="profile-card-title-options">
                                            <div id="profile-card-title-options-body">
                                                <h1 id="patient_id"><span>MDCN:</span> gh2ik82j6r78</h1>
                                                <ul id="id-details">
                                                    <li><span>Specialty:</span></li>
                                                    <li><span>Hospital:</span></li>
                                                    <li><span>Practising since:</span></li>
                                                    <li><span>Consultation Fee:</span></li>
                                                </ul>
                                                <a href="./profile.php">Edit</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    <script src="assets/js/jquery-2.0.3.min.js"></script>
    <script src="assets/js/index.js"></script>
</html>