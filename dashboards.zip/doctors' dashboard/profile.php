<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">

        <link rel="icon" href="assets/images/.jpg">
        <title>Change account data || Firstmedtrade Africa - Africa's foremost online medical platform.</title>

        <link href="../users%20dashboard/assets/css/main.css" type="text/css" rel="stylesheet"/>
        <link rel="stylesheet" type="text/css" href="../users%20dashboard/assets/css/mediaqueries.css" />
        <link rel="stylesheet" href="https://cdn.materialdesignicons.com/3.2.89/css/materialdesignicons.min.css">
    </head>
    <body>
        <div class="profilewrapper profile doc">
            <div class="profile-left sidebarnav-width">
                <div class="profile-sidenav">
                    <span id="exitpa"><i class="mdi mdi-close"></i></span>
                    <p><a href="./"><i class="mdi mdi-speedometer"></i>DASHBOARD</a></p>
                    <hr>
                    <p><a href="./appointments.php"><i class="mdi mdi-briefcase"></i>MY APPOINTMENTS</a></p>
                    <p><a href="./schedule.php"><i class="mdi mdi-calendar-multiselect"></i>MY SCHEDULER</a></p>
                    <hr>
                    <p><a href="#" class="active"><i class="mdi mdi-account"></i>PROFILE DATA</a></p>
                    <p><a href="./password.php"><i class="mdi mdi-lock-open-outline"></i>CHANGE PASSWORD</a></p>
                </div>
                <div class="sidenav-footer">
                    <div class="sidenav-footer-links">
                        <a href="#"><i class="mdi mdi-logout"></i>Logout</a>
                    </div>
                </div>
            </div>
            <div class="profile-right marginal">
                <div class="profile-nav">
                    <span id="sidenav-opener"><i class="mdi mdi-menu"></i></span>
                    <div class="profilenav-left">
                        <div id="profilenav-left-image">
                            <img src="assets/images/FMedTrademinilogo.png">
                        </div>
                        <div id="profilenav-left-text">
                            <h5>Firstmedtrade</h5>
                        </div>
                    </div>
                    <div class="profilenav-right">
                        <div class="welcome-user">
                            <div class="user-div">
                                <div class="user-img">
                                    <i class="mdi mdi-account-outline"></i>
                                </div>
                                <?php echo '<p>Ubyjude Josh</p>'?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="profilebody">
                    <div class="profilepage-pagination">
                        <div class="pageNumber">
                            <p><a href="#"><i class="mdi mdi-home"></i>Home</a> / <a href="./">Dashboard</a> / Profile Data</p>
                        </div>
                    </div>
                    <div class="profilebody-body data">
                        <div class="profilebody-left">
                            <form name="updatedata" action="profile.php" method="post">
                                <h1>Physician Details</h1>
                                <div class="form-group">
                                    <h4><span>MDCN:</span></h4>
                                    <div class="form-group-minor">
                                        <label for="name">Name</label>
                                        <input type="text" name="name" size="20" minlength="6" maxlength="30">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="birthdate">Birth Date</label>
                                        <input type="date" name="birthdate" min="1940-01-01" max="2000-12-31" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="sex">Sex</label>
                                        <input type="text" list="sex" name="sex" minlength="4" maxlength="6">
                                        <datalist id="sex">
                                            <option value="Male">
                                            <option value="Female">
                                        </datalist>
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="bio">Bio</label>
                                        <textarea name="bio" minlength="100" maxlength="500"></textarea>
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="type">Type</label>
                                        <input type="text" list="type" name="type" minlength="4">
                                        <datalist id="type">
                                            <option value="Consultant">
                                            <option value="Resident">
                                            <option value="Specialist">
                                            <option value="Intern">
                                            <option value="General Practitioner">
                                        </datalist>
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="specialty">Specialty</label>
                                        <input type="text" list="specialty" name="specialty" minlength="4">
                                        <datalist id ="specialty">
                                            <option value="Accident and emergency medicine">
                                            <option value="Allergology">
                                            <option value="Anaesthetics">
                                            <option value="Biological hematology">
                                            <option value="Cardiology">
                                            <option value="Child psychiatry">
                                            <option value="Clinical biology">
                                            <option value="Clinical chemistry">
                                            <option value="Clinical neurophysiology">
                                            <option value="Craniofacial surgery">
                                            <option value="Dental">
                                            <option value="Dermato-venereology">
                                            <option value="Dermatology">
                                            <option value="Endocrinology">
                                            <option value="Gastro-enterologic surgery">
                                            <option value="Gastroenterology">
                                            <option value="General hematology">
                                            <option value="General Practice">
                                            <option value="General surgery">
                                            <option value="Geriatrics">
                                            <option value="Immunology">
                                            <option value="Infectious diseases">
                                            <option value="Internal medicine">
                                            <option value="Laboratory medicine">
                                            <option value="Maxillo-facial surgery">
                                            <option value="Microbiology">
                                            <option value="Nephrology">
                                            <option value="Neuro-psychiatry">
                                            <option value="Neurology">
                                            <option value="Neurosurgery">
                                            <option value="Nuclear medicine">
                                            <option value="Obstetrics and gynecology">
                                            <option value="Occupational medicine">
                                            <option value="Ophthalmology">
                                            <option value="Orthopaedics">
                                            <option value="Otorhinolaryngology">
                                            <option value="Paediatric surgery">
                                            <option value="Paediatrics">
                                            <option value="Pathology">
                                            <option value="Pharmacology">
                                            <option value="Physical medicine and rehabilitation">
                                            <option value="Plastic surgery">
                                            <option value="Podiatric Surgery">
                                            <option value="Psychiatry">
                                            <option value="Public health and Preventive Medicine">
                                            <option value="Radiation Oncology">
                                            <option value="Radiology">
                                            <option value="Respiratory medicine">
                                            <option value="Rheumatology">
                                            <option value="Stomatology">
                                            <option value="Thoracic surgery">
                                            <option value="Tropical medicine">
                                            <option value="Urology">
                                            <option value="Vascular surgery">
                                            <option value="Venereology">
                                        </datalist>
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="hospitalname">Hospital Name</label>
                                        <input type="text" name="hospitalname" minlength="2" maxlength="40">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="hospitaladdress">Hospital Address</label>
                                        <input type="text" name="hospitaladdress" minlength="2" maxlength="150">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="hospitalstate">Hospital Location</label>
                                        <input type="text" list="hospitalstate" name="hospitalstate" minlength="2" maxlength="40">
                                    </div>    
                                    <div class="form-group-minor">
                                        <label for="country">Residential Country</label>
                                        <input type="text" name="country" size="20" minlength="6" maxlength="30">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="country">Residential City</label>
                                        <input type="text" name="country" size="20" minlength="6" maxlength="30">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="practicedate">Practicing Since</label>
                                        <input type="date" name="practicedate" min="1940-01-01" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="mdcn">MDCN</label>
                                        <input type="text" name="mdcn" maxlength="20">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="consultationFee">Consultation Fee</label>
                                        <input type="number" name="consultationFee" min="5000" max="50000" maxlength="5">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="insitutionname">Institution Name</label>
                                        <input type="text" name="insitutionname" size="20" minlength="6" maxlength="40">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="completedate">Date Completed</label>
                                        <input type="date" name="completedate" min="1940-01-01" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="qualification">Qualification</label>
                                        <input type="text" name="qualification" size="20" minlength="6" maxlength="30">
                                    </div>
                               </div>
                                <div class="form-group">
                                    <button type="submit" name="updatePatientdata"><i class="mdi mdi-content-save"></i>Save</button>
                                </div>
                            </form>
                        </div>
                        <div class="profilebody-right">
                        <form name="updatedata" action="profile.php" method="post">
                                <h1>User Details</h1>
                                <div class="form-group">
                                    <div class="form-group-minor">
                                        <div id="dp">
                                            <div id="dp-img">
                                                <div class="form-group-minute">
                                                    <label for="upimage" class="btn btn-large"><i class="mdi mdi-camera"></i>Upload</label>
                                                    <input id="upimage" name="upimage" type='file' accept="image/*"/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="fname">First Name</label>
                                        <input type="text" name="fname" size="20" minlength="6" maxlength="14">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="lname">Last Name</label>
                                        <input type="text" name="lname" size="20" minlength="6" maxlength="14">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="phone">Phone Number</label>
                                        <input type="tel" name="phone" size="20" minlength="6" maxlength="14">
                                    </div>
                                    <div class="form-group-minor">
                                        <label for="email">Email</label>
                                        <input type="email" name="email" size="20" minlength="6" maxlength="40">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" name="updateUserdata"><i class="mdi mdi-content-save"></i>Save</button>
                                </div>
                            </form>
                        </div>
                   </div>
                </div>
            </div>
        </div>
    </body>
    <script src="assets/js/jquery-2.0.3.min.js"></script>
    <script src="assets/js/index.js"></script>
</html>