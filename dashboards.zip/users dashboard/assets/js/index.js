//profile page
$(function(){
    $('#sidenav-opener').click(function() {
        $('.profile-left').toggleClass('sidebarnav-width');
        $('.profile-right').toggleClass('marginal');
    });
    $('#exitpa').click(function() {
        $('.profile-left').removeClass('sidebarnav-width');
        $('.profile-right').removeClass('marginal');
    });
});

//today's Date
var monthNames = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
var dayNames= ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
var newDate = new Date();
$('#date').html(dayNames[newDate.getDay()] + "," + ' ' + newDate.getDate() + " " + monthNames[newDate.getMonth()] + ',' + " " + newDate.getFullYear());



